import { BrowserRouter, Route, Routes } from "react-router";
import Home from "./pages";
import Books from "./pages/books";
import Teams from "./pages/Teams";
import Contact from "./pages/contacts";

function App() {
  return (
    <>
      <div className="container">
        <BrowserRouter>
          <Routes>
            <Route index element={<Home />} />
            <Route path="books" element={<Books />} />
            <Route path="teams" element={<Teams/>}/>
            <Route path="contacts" element={<Contact/>}/>
          </Routes>
        </BrowserRouter>
      </div>
    </>
  );
}

export default App;
