import Footer from "../../components/shared/Footer";
import Header from "../../components/shared/Header";
import ProudctList from "../../components/shared/productList";

export default function Books() {
  return (
    <>
      <Header />
      <ProudctList />
      <Footer />
    </>
  );
}
