import Header from "../../components/shared/Header";
import ProudctList from "../../components/shared/productList";

export default function Teams (){
    return (
        <>
        <Header/>
        <ProudctList/>
        </>
    )
}