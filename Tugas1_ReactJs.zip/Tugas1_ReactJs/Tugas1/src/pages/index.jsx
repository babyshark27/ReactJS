import Footer from "../components/shared/Footer";
import Header from "../components/shared/Header";
import Hero from "../components/shared/Hero";
import ProudctList from "../components/shared/productList";

export default function Home() {
  return (
    <>
      <Header />
      <Hero />
      <ProudctList />
      <Footer/>
    </>
  );
}
